'use client'

import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Progress } from '@/components/ui/progress'
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group'
import { Label } from '@/components/ui/label'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { 
  CheckCircle2, 
  AlertTriangle, 
  AlertCircle, 
  ChevronRight, 
  ChevronLeft, 
  Building2, 
  Cog, 
  Monitor, 
  FileText, 
  TrendingUp,
  Shield,
  Users,
  Clock,
  Phone,
  Mail,
  ArrowRight,
  Sparkles,
  Target,
  Zap,
  Download,
  Loader2,
  DollarSign
} from 'lucide-react'
import { checkupQuestions, calculateResult, type Question, type CheckupResult } from '@/data/checkup-questions'

type Step = 'intro' | 'register' | 'questions' | 'agradecimento'

interface LeadData {
  nome: string
  email: string
  telefone: string
  tipoInstituicao: string
  cargo: string
  qtdFuncionarios: string
}

export default function CheckupCME() {
  const [step, setStep] = useState<Step>('intro')
  const [currentCategory, setCurrentCategory] = useState<'gestao' | 'processo' | 'tecnologia' | 'financeiro'>('gestao')
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0)
  const [answers, setAnswers] = useState<Record<string, number>>({})
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [leadData, setLeadData] = useState<LeadData>({
    nome: '',
    email: '',
    telefone: '',
    tipoInstituicao: '',
    cargo: '',
    qtdFuncionarios: ''
  })

  const categories = ['gestao', 'processo', 'tecnologia', 'financeiro'] as const
  const currentCategoryIndex = categories.indexOf(currentCategory)
  const categoryQuestions = checkupQuestions.filter(q => q.category === currentCategory)
  const currentQuestion = categoryQuestions[currentQuestionIndex]
  
  const totalQuestions = checkupQuestions.length
  const answeredQuestions = Object.keys(answers).length
  const progress = (answeredQuestions / totalQuestions) * 100

  // Calcular questões respondidas por categoria
  const questionsByCategory = {
    gestao: checkupQuestions.filter(q => q.category === 'gestao'),
    processo: checkupQuestions.filter(q => q.category === 'processo'),
    tecnologia: checkupQuestions.filter(q => q.category === 'tecnologia'),
    financeiro: checkupQuestions.filter(q => q.category === 'financeiro')
  }

  const handleAnswer = (questionId: string, value: number) => {
    setAnswers(prev => ({ ...prev, [questionId]: value }))
  }

  const handleNext = () => {
    if (currentQuestionIndex < categoryQuestions.length - 1) {
      setCurrentQuestionIndex(prev => prev + 1)
    } else if (currentCategoryIndex < categories.length - 1) {
      // Próxima categoria
      setCurrentCategory(categories[currentCategoryIndex + 1] as typeof currentCategory)
      setCurrentQuestionIndex(0)
    } else {
      // Finalizar questionário - enviar para API
      handleFinalizar()
    }
  }

  const handleFinalizar = async () => {
    setIsSubmitting(true)
    try {
      const response = await fetch('/api/avaliacoes', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ leadData, answers })
      })
      
      const data = await response.json()
      
      if (data.success) {
        setStep('agradecimento')
      } else {
        alert('Erro ao enviar avaliação. Tente novamente.')
      }
    } catch (error) {
      console.error('Erro ao enviar:', error)
      alert('Erro ao enviar avaliação. Tente novamente.')
    } finally {
      setIsSubmitting(false)
    }
  }

  const handlePrevious = () => {
    if (currentQuestionIndex > 0) {
      setCurrentQuestionIndex(prev => prev - 1)
    } else if (currentCategoryIndex > 0) {
      // Categoria anterior
      const prevCategory = categories[currentCategoryIndex - 1] as typeof currentCategory
      setCurrentCategory(prevCategory)
      setCurrentQuestionIndex(questionsByCategory[prevCategory].length - 1)
    }
  }

  const handleStartQuestions = () => {
    if (leadData.nome && leadData.email && leadData.tipoInstituicao) {
      setStep('questions')
      setCurrentCategory('gestao')
      setCurrentQuestionIndex(0)
    }
  }

  const getLevelColor = (level: string) => {
    switch (level) {
      case 'critico': return 'text-red-600 bg-red-50 border-red-200'
      case 'necessita_melhorias': return 'text-orange-600 bg-orange-50 border-orange-200'
      case 'precisa_tecnologia': return 'text-amber-600 bg-amber-50 border-amber-200'
      case 'em_desenvolvimento': return 'text-blue-600 bg-blue-50 border-blue-200'
      default: return 'text-gray-600 bg-gray-50'
    }
  }

  const getLevelIcon = (level: string) => {
    switch (level) {
      case 'critico': return <AlertCircle className="w-5 h-5" />
      case 'necessita_melhorias': return <AlertTriangle className="w-5 h-5" />
      case 'precisa_tecnologia': return <Monitor className="w-5 h-5" />
      case 'em_desenvolvimento': return <TrendingUp className="w-5 h-5" />
      default: return null
    }
  }

  const getLevelText = (level: string) => {
    switch (level) {
      case 'critico': return 'CRÍTICO - Riscos Elevados'
      case 'necessita_melhorias': return 'NECESSITA MELHORIAS SIGNIFICATIVAS'
      case 'precisa_tecnologia': return 'PRECISA DE TECNOLOGIA E PROCESSOS'
      case 'em_desenvolvimento': return 'EM DESENVOLVIMENTO - Oportunidade de Evolução'
      default: return ''
    }
  }

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'gestao': return <Building2 className="w-5 h-5" />
      case 'processo': return <Cog className="w-5 h-5" />
      case 'tecnologia': return <Monitor className="w-5 h-5" />
      case 'financeiro': return <DollarSign className="w-5 h-5" />
      default: return null
    }
  }

  // Página de Introdução
  if (step === 'intro') {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-slate-100">
        <div className="container mx-auto px-4 py-8 md:py-16">
          <div className="max-w-4xl mx-auto">
            {/* Header */}
            <div className="text-center mb-12">
              <div className="inline-flex items-center gap-2 bg-green-100 text-green-700 px-4 py-2 rounded-full text-sm font-medium mb-6">
                <Shield className="w-4 h-4" />
                100% Gratuito e Confidencial
              </div>
              <h1 className="text-4xl md:text-5xl font-bold text-slate-900 mb-4">
                Checkup CME Inteligente
              </h1>
              <p className="text-xl text-slate-600 mb-2">
                Diagnóstico de Gestão, Processo e Tecnologia
              </p>
              <p className="text-slate-500">
                Descubra o ranking da sua CME e receba um laudo personalizado com recomendações
              </p>
            </div>

            {/* Cards de benefícios */}
            <div className="grid md:grid-cols-3 gap-6 mb-12">
              <Card className="border-0 shadow-lg hover:shadow-xl transition-shadow">
                <CardHeader className="pb-2">
                  <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mb-3">
                    <FileText className="w-6 h-6 text-blue-600" />
                  </div>
                  <CardTitle className="text-lg">Laudo Personalizado</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription className="text-slate-600">
                    Receba um diagnóstico completo com pontos críticos e recomendações específicas para sua CME
                  </CardDescription>
                </CardContent>
              </Card>

              <Card className="border-0 shadow-lg hover:shadow-xl transition-shadow">
                <CardHeader className="pb-2">
                  <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center mb-3">
                    <TrendingUp className="w-6 h-6 text-green-600" />
                  </div>
                  <CardTitle className="text-lg">Economia Estimada</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription className="text-slate-600">
                    Saiba quanto sua CME pode economizar com melhorias em processos e tecnologia
                  </CardDescription>
                </CardContent>
              </Card>

              <Card className="border-0 shadow-lg hover:shadow-xl transition-shadow">
                <CardHeader className="pb-2">
                  <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center mb-3">
                    <Target className="w-6 h-6 text-purple-600" />
                  </div>
                  <CardTitle className="text-lg">Plano de Ação</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription className="text-slate-600">
                    Quick wins e próximos passos claros para transformar sua CME
                  </CardDescription>
                </CardContent>
              </Card>
            </div>

            {/* Preview das categorias */}
            <Card className="border-0 shadow-lg mb-8">
              <CardHeader>
                <CardTitle className="text-center">O Checkup Avalia 4 Dimensões</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-4 gap-4">
                  <div className="flex items-center gap-3 p-4 bg-blue-50 rounded-lg">
                    <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                      <Building2 className="w-5 h-5 text-blue-600" />
                    </div>
                    <div>
                      <p className="font-semibold text-blue-900">Gestão</p>
                      <p className="text-sm text-blue-700">9 questões</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3 p-4 bg-green-50 rounded-lg">
                    <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center">
                      <Cog className="w-5 h-5 text-green-600" />
                    </div>
                    <div>
                      <p className="font-semibold text-green-900">Processo</p>
                      <p className="text-sm text-green-700">12 questões</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3 p-4 bg-purple-50 rounded-lg">
                    <div className="w-10 h-10 bg-purple-100 rounded-full flex items-center justify-center">
                      <Monitor className="w-5 h-5 text-purple-600" />
                    </div>
                    <div>
                      <p className="font-semibold text-purple-900">Tecnologia</p>
                      <p className="text-sm text-purple-700">9 questões</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3 p-4 bg-amber-50 rounded-lg">
                    <div className="w-10 h-10 bg-amber-100 rounded-full flex items-center justify-center">
                      <DollarSign className="w-5 h-5 text-amber-600" />
                    </div>
                    <div>
                      <p className="font-semibold text-amber-900">Financeiro</p>
                      <p className="text-sm text-amber-700">10 questões</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Especialista - Klever Oliveira Lopes */}
            <Card className="border-2 border-green-200 bg-gradient-to-br from-green-50 to-white mb-8 overflow-hidden">
              <CardContent className="p-0">
                {/* Header com foto */}
                <div className="bg-gradient-to-r from-green-600 to-green-700 p-6">
                  <div className="flex flex-col md:flex-row items-center gap-6">
                    <div className="relative">
                      <img 
                        src="/klever-foto.jpeg" 
                        alt="Klever Oliveira Lopes"
                        className="w-32 h-32 rounded-full object-cover border-4 border-white shadow-xl"
                      />
                      <div className="absolute -bottom-2 -right-2 bg-white rounded-full p-2 shadow-lg">
                        <Shield className="w-6 h-6 text-green-600" />
                      </div>
                    </div>
                    <div className="flex-1 text-center md:text-left">
                      <p className="text-green-100 text-sm font-medium mb-1">CHECKUP REALIZADO POR</p>
                      <h3 className="text-2xl font-bold text-white mb-2">Klever Oliveira Lopes</h3>
                      <p className="text-green-100">Enfermeiro | Especialista em CME</p>
                      <p className="text-green-200 text-sm mt-1">+20 anos de experiência em gestão hospitalar</p>
                    </div>
                  </div>
                </div>
                
                {/* Currículo completo */}
                <div className="p-6 space-y-4">
                  <p className="text-slate-700 leading-relaxed">
                    <strong className="text-slate-900">Klever Oliveira Lopes</strong> é enfermeiro, especialista em CME e uma das referências quando o assunto é <strong>gestão, qualificação de processos, rastreabilidade, tecnologia aplicada e inteligência operacional</strong> no reprocessamento de produtos para saúde.
                  </p>
                  
                  <p className="text-slate-700 leading-relaxed">
                    Com mais de 20 anos de experiência em gestão hospitalar, operações e áreas estratégicas de apoio, Klever construiu uma visão prática e analítica sobre os bastidores da assistência, entendendo com profundidade <strong>onde a rotina perde controle, onde surgem fragilidades silenciosas</strong> e como a CME pode deixar de atuar apenas no operacional para assumir um papel mais estratégico dentro da instituição.
                  </p>
                  
                  <div className="bg-green-50 p-4 rounded-lg border border-green-200">
                    <p className="text-slate-700 leading-relaxed">
                      <strong className="text-green-800">Experiência Prática:</strong> Participou da estruturação e construção de CMEs em diferentes regiões do Brasil, atuando em projetos com alta tecnologia e operação em grande escala. Essa vivência deu a ele não apenas conhecimento técnico, mas visão real de como transformar a CME em uma operação mais organizada, segura, rastreável e preparada para crescer com controle.
                    </p>
                  </div>
                  
                  <p className="text-slate-700 leading-relaxed">
                    Nos últimos anos, concentrou sua atuação na evolução da CME por meio da <strong>tecnologia, da padronização, da rastreabilidade, dos indicadores e da gestão orientada por dados</strong>. Foi a partir dessa visão que estruturou o conceito de <strong>CME Inteligente</strong>: uma central mais estratégica, mais comprovável, mais gerenciável e mais conectada à tomada de decisão.
                  </p>
                  
                  <div className="bg-slate-50 p-4 rounded-lg border border-slate-200">
                    <p className="text-slate-700 leading-relaxed mb-3">
                      <strong className="text-slate-900">À frente da CME Inteligente, Klever atua integrando:</strong>
                    </p>
                    <ul className="grid md:grid-cols-2 gap-2 text-sm text-slate-600">
                      <li className="flex items-center gap-2">
                        <CheckCircle2 className="w-4 h-4 text-green-600" />
                        Tecnologia
                      </li>
                      <li className="flex items-center gap-2">
                        <CheckCircle2 className="w-4 h-4 text-green-600" />
                        Segurança do paciente
                      </li>
                      <li className="flex items-center gap-2">
                        <CheckCircle2 className="w-4 h-4 text-green-600" />
                        Governança
                      </li>
                      <li className="flex items-center gap-2">
                        <CheckCircle2 className="w-4 h-4 text-green-600" />
                        Eficiência operacional
                      </li>
                      <li className="flex items-center gap-2">
                        <CheckCircle2 className="w-4 h-4 text-green-600" />
                        Estratégia de dados
                      </li>
                      <li className="flex items-center gap-2">
                        <CheckCircle2 className="w-4 h-4 text-green-600" />
                        Rastreabilidade estruturada
                      </li>
                    </ul>
                  </div>
                  
                  <p className="text-slate-600 italic text-sm leading-relaxed">
                    "Não basta manter a rotina funcionando nem apenas registrar etapas. É preciso estruturar processos, dar utilidade gerencial à rastreabilidade, organizar dados operacionais e criar clareza para decisões mais seguras e mais eficientes."
                  </p>
                  
                  <div className="text-center pt-2">
                    <p className="text-xs text-slate-500">
                      CME Inteligente
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Botão para começar */}
            <div className="text-center">
              <Button 
                onClick={() => setStep('register')}
                size="lg"
                className="bg-green-600 hover:bg-green-700 text-white px-12 py-6 text-lg font-semibold rounded-xl shadow-lg hover:shadow-xl transition-all"
              >
                Iniciar Checkup Gratuito
                <ArrowRight className="ml-2 w-5 h-5" />
              </Button>
              <p className="text-slate-500 text-sm mt-4">
                <Clock className="w-4 h-4 inline mr-1" />
                Aproximadamente 10 minutos
              </p>
            </div>
          </div>
        </div>
      </div>
    )
  }

  // Página de Registro
  if (step === 'register') {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-slate-100">
        <div className="container mx-auto px-4 py-8 md:py-16">
          <div className="max-w-xl mx-auto">
            <Button 
              variant="ghost" 
              onClick={() => setStep('intro')}
              className="mb-6"
            >
              <ChevronLeft className="w-4 h-4 mr-2" />
              Voltar
            </Button>

            <Card className="border-0 shadow-xl">
              <CardHeader className="text-center pb-2">
                <CardTitle className="text-2xl">Seus Dados</CardTitle>
                <CardDescription>
                  Precisamos de algumas informações para personalizar seu laudo
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="nome">Nome Completo *</Label>
                  <Input 
                    id="nome"
                    placeholder="Seu nome"
                    value={leadData.nome}
                    onChange={(e) => setLeadData(prev => ({ ...prev, nome: e.target.value }))}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="email">E-mail Corporativo *</Label>
                  <Input 
                    id="email"
                    type="email"
                    placeholder="seu.email@hospital.com.br"
                    value={leadData.email}
                    onChange={(e) => setLeadData(prev => ({ ...prev, email: e.target.value }))}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="telefone">Telefone/WhatsApp</Label>
                  <Input 
                    id="telefone"
                    placeholder="(11) 99999-9999"
                    value={leadData.telefone}
                    onChange={(e) => setLeadData(prev => ({ ...prev, telefone: e.target.value }))}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="tipoInstituicao">Tipo de Instituição *</Label>
                  <RadioGroup 
                    value={leadData.tipoInstituicao}
                    onValueChange={(value) => setLeadData(prev => ({ ...prev, tipoInstituicao: value }))}
                    className="grid grid-cols-2 gap-2"
                  >
                    {['Clínica', 'Hospital Dia', 'Hospital Geral', 'Hospital de Especialidade'].map((tipo) => (
                      <div 
                        key={tipo}
                        className={`flex items-center justify-center space-x-2 p-3 rounded-lg border-2 transition-all cursor-pointer text-sm ${
                          leadData.tipoInstituicao === tipo 
                            ? 'border-green-500 bg-green-50 text-green-700' 
                            : 'border-slate-200 hover:border-slate-300 hover:bg-slate-50'
                        }`}
                        onClick={() => setLeadData(prev => ({ ...prev, tipoInstituicao: tipo }))}
                      >
                        <RadioGroupItem value={tipo} id={`tipo-${tipo}`} className="sr-only" />
                        <Label htmlFor={`tipo-${tipo}`} className="cursor-pointer font-medium">
                          {tipo}
                        </Label>
                      </div>
                    ))}
                  </RadioGroup>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="cargo">Cargo</Label>
                  <Input 
                    id="cargo"
                    placeholder="Ex: Enfermeiro Responsável Técnico"
                    value={leadData.cargo}
                    onChange={(e) => setLeadData(prev => ({ ...prev, cargo: e.target.value }))}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="qtdFuncionarios">Quantidade de Funcionários Dedicados ao CME</Label>
                  <RadioGroup 
                    value={leadData.qtdFuncionarios}
                    onValueChange={(value) => setLeadData(prev => ({ ...prev, qtdFuncionarios: value }))}
                    className="grid grid-cols-2 gap-2"
                  >
                    {['1 a 5', '6 a 10', '11 a 20', 'Mais de 20'].map((qtd) => (
                      <div 
                        key={qtd}
                        className={`flex items-center justify-center space-x-2 p-3 rounded-lg border-2 transition-all cursor-pointer text-sm ${
                          leadData.qtdFuncionarios === qtd 
                            ? 'border-green-500 bg-green-50 text-green-700' 
                            : 'border-slate-200 hover:border-slate-300 hover:bg-slate-50'
                        }`}
                        onClick={() => setLeadData(prev => ({ ...prev, qtdFuncionarios: qtd }))}
                      >
                        <RadioGroupItem value={qtd} id={`qtd-${qtd}`} className="sr-only" />
                        <Label htmlFor={`qtd-${qtd}`} className="cursor-pointer font-medium">
                          {qtd}
                        </Label>
                      </div>
                    ))}
                  </RadioGroup>
                </div>

                <div className="pt-4">
                  <Button 
                    onClick={handleStartQuestions}
                    disabled={!leadData.nome || !leadData.email || !leadData.tipoInstituicao}
                    className="w-full bg-green-600 hover:bg-green-700 py-6 text-lg font-semibold"
                  >
                    Começar Questionário
                    <ArrowRight className="ml-2 w-5 h-5" />
                  </Button>
                </div>

                <p className="text-xs text-slate-500 text-center">
                  Seus dados estão seguros e serão usados apenas para enviar seu laudo personalizado
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    )
  }

  // Página de Perguntas
  if (step === 'questions') {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-slate-100">
        <div className="container mx-auto px-4 py-6 md:py-10">
          <div className="max-w-3xl mx-auto">
            {/* Progress Header */}
            <div className="mb-8">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm text-slate-600">Progresso Geral</span>
                <span className="text-sm font-medium text-slate-900">{Math.round(progress)}%</span>
              </div>
              <Progress value={progress} className="h-2" />
              
              {/* Category indicators */}
              <div className="flex gap-4 mt-4">
                {categories.map((cat, idx) => {
                  const catQuestions = questionsByCategory[cat]
                  const answeredInCat = catQuestions.filter(q => answers[q.id]).length
                  const isCurrentCat = cat === currentCategory
                  const isCompleted = answeredInCat === catQuestions.length
                  
                  return (
                    <div 
                      key={cat}
                      className={`flex items-center gap-2 px-3 py-1.5 rounded-full text-sm ${
                        isCurrentCat 
                          ? 'bg-green-100 text-green-700 font-medium' 
                          : isCompleted 
                            ? 'bg-slate-100 text-slate-600' 
                            : 'text-slate-400'
                      }`}
                    >
                      {getCategoryIcon(cat)}
                      <span className="hidden sm:inline capitalize">{cat}</span>
                      <span className="text-xs">({answeredInCat}/{catQuestions.length})</span>
                    </div>
                  )
                })}
              </div>
            </div>

            {/* Question Card */}
            {currentQuestion && (
              <Card className="border-0 shadow-xl mb-6">
                <CardHeader className="pb-2">
                  <div className="flex items-center gap-2 text-sm text-slate-500 mb-2">
                    {getCategoryIcon(currentCategory)}
                    <span className="capitalize">{currentCategory}</span>
                    <span>•</span>
                    <span>Questão {currentQuestionIndex + 1} de {categoryQuestions.length}</span>
                  </div>
                  <CardTitle className="text-xl md:text-2xl">
                    {currentQuestion.question}
                  </CardTitle>
                  {currentQuestion.description && (
                    <CardDescription className="text-slate-600 mt-2">
                      {currentQuestion.description}
                    </CardDescription>
                  )}
                </CardHeader>
                <CardContent>
                  <RadioGroup 
                    value={answers[currentQuestion.id]?.toString() || ''}
                    onValueChange={(value) => handleAnswer(currentQuestion.id, parseInt(value))}
                    className="space-y-3"
                  >
                    {currentQuestion.options.map((option) => (
                      <div 
                        key={option.value}
                        className={`flex items-start space-x-3 p-4 rounded-lg border-2 transition-all cursor-pointer ${
                          option.value === 0 
                            ? 'border-dashed border-slate-300 bg-slate-50/50 hover:border-slate-400 hover:bg-slate-100/50' 
                            : answers[currentQuestion.id] === option.value 
                              ? 'border-green-500 bg-green-50' 
                              : 'border-slate-200 hover:border-slate-300 hover:bg-slate-50'
                        } ${
                          answers[currentQuestion.id] === 0 && option.value === 0 
                            ? 'border-amber-400 bg-amber-50' 
                            : ''
                        }`}
                        onClick={() => handleAnswer(currentQuestion.id, option.value)}
                      >
                        <RadioGroupItem value={option.value.toString()} id={`option-${option.value}`} className="mt-0.5" />
                        <div className="flex-1">
                          <Label 
                            htmlFor={`option-${option.value}`} 
                            className={`cursor-pointer font-medium ${
                              option.value === 0 ? 'text-slate-500 italic' : 'text-slate-900'
                            }`}
                          >
                            {option.label}
                          </Label>
                          <p className={`text-sm mt-1 ${
                            option.value === 0 ? 'text-slate-500' : 'text-slate-600'
                          }`}>{option.impact}</p>
                        </div>
                      </div>
                    ))}
                  </RadioGroup>
                </CardContent>
              </Card>
            )}

            {/* Navigation */}
            <div className="flex justify-between">
              <Button 
                variant="outline"
                onClick={handlePrevious}
                disabled={currentCategoryIndex === 0 && currentQuestionIndex === 0}
              >
                <ChevronLeft className="w-4 h-4 mr-2" />
                Anterior
              </Button>

              <Button 
                onClick={handleNext}
                disabled={answers[currentQuestion?.id] === undefined || isSubmitting}
                className="bg-green-600 hover:bg-green-700"
              >
                {isSubmitting ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Enviando...
                  </>
                ) : (
                  <>
                    {currentCategoryIndex === categories.length - 1 && currentQuestionIndex === categoryQuestions.length - 1 
                      ? 'Finalizar' 
                      : 'Próxima'}
                    <ChevronRight className="w-4 h-4 ml-2" />
                  </>
                )}
              </Button>
            </div>
          </div>
        </div>
      </div>
    )
  }

  // Página de Agradecimento
  if (step === 'agradecimento') {
    return (
      <div className="min-h-screen bg-gradient-to-br from-green-50 via-white to-green-100 flex items-center justify-center p-4">
        <Card className="max-w-2xl w-full border-0 shadow-2xl">
          <CardContent className="pt-12 pb-12 px-8 text-center">
            {/* Ícone de sucesso */}
            <div className="w-24 h-24 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-8">
              <CheckCircle2 className="w-12 h-12 text-green-600" />
            </div>
            
            {/* Título */}
            <h1 className="text-3xl md:text-4xl font-bold text-slate-900 mb-4">
              Avaliação Enviada com Sucesso!
            </h1>
            
            {/* Mensagem */}
            <p className="text-lg text-slate-600 mb-6">
              Obrigado por realizar o Checkup CME, <strong>{leadData.nome}</strong>!
            </p>
            
            <div className="bg-green-50 border border-green-200 rounded-xl p-6 mb-8">
              <p className="text-slate-700 leading-relaxed">
                Nossa equipe receberá suas respostas e entrará em contato em breve com uma 
                <strong> análise personalizada</strong> do seu diagnóstico, identificando oportunidades 
                de melhoria específicas para sua instituição.
              </p>
            </div>
            
            {/* Informações de contato */}
            <div className="bg-slate-50 rounded-xl p-6 mb-8">
              <h3 className="font-semibold text-slate-900 mb-4">Próximos Passos:</h3>
              <ul className="text-left space-y-3">
                <li className="flex items-start gap-3">
                  <div className="w-6 h-6 bg-green-100 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                    <span className="text-xs font-bold text-green-600">1</span>
                  </div>
                  <span className="text-slate-700">Nossa equipe vai analisar suas respostas</span>
                </li>
                <li className="flex items-start gap-3">
                  <div className="w-6 h-6 bg-green-100 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                    <span className="text-xs font-bold text-green-600">2</span>
                  </div>
                  <span className="text-slate-700">Você receberá um diagnóstico personalizado</span>
                </li>
                <li className="flex items-start gap-3">
                  <div className="w-6 h-6 bg-green-100 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                    <span className="text-xs font-bold text-green-600">3</span>
                  </div>
                  <span className="text-slate-700">Vamos apresentar soluções específicas para sua CME</span>
                </li>
              </ul>
            </div>
            
            {/* Contato direto */}
            <div className="flex flex-col sm:flex-row gap-4 justify-center mb-8">
              <Button 
                size="lg"
                className="bg-green-600 hover:bg-green-700 text-white px-8"
                onClick={() => window.open('https://wa.me/5511999999999?text=Olá! Acabei de fazer o Checkup CME e gostaria de mais informações.', '_blank')}
              >
                <Phone className="w-5 h-5 mr-2" />
                Falar pelo WhatsApp
              </Button>
              <Button 
                size="lg"
                variant="outline"
                className="border-green-600 text-green-700"
                onClick={() => window.open('mailto:contato@cmeinteligente.com.br', '_blank')}
              >
                <Mail className="w-5 h-5 mr-2" />
                Enviar E-mail
              </Button>
            </div>
            
            {/* Assinatura */}
            <div className="pt-6 border-t border-slate-200">
              <div className="flex items-center justify-center gap-4">
                <img 
                  src="/klever-foto.jpeg" 
                  alt="Klever Oliveira Lopes"
                  className="w-12 h-12 rounded-full object-cover border-2 border-green-200"
                />
                <div className="text-left">
                  <p className="font-semibold text-slate-900">Klever Oliveira Lopes</p>
                  <p className="text-sm text-slate-600">Enfermeiro | Especialista em CME</p>
                </div>
              </div>
            </div>
            
            {/* Botão reiniciar */}
            <Button 
              variant="ghost"
              className="mt-8"
              onClick={() => {
                setStep('intro')
                setAnswers({})
                setCurrentCategory('gestao')
                setCurrentQuestionIndex(0)
              }}
            >
              Fazer novo checkup
            </Button>
          </CardContent>
        </Card>
      </div>
    )
  }

  return null
}
