import { NextRequest, NextResponse } from 'next/server'
import { jsPDF } from 'jspdf'

interface CategoryResult {
  category: string
  categoryName: string
  score: number
  maxScore: number
  percentage: number
  level: string
  findings: string[]
  recommendations: string[]
}

interface CheckupResult {
  overallScore: number
  overallLevel: string
  categories: CategoryResult[]
  mainProblems: string[]
  quickWins: string[]
  economyEstimate: {
    min: number
    max: number
    description: string
  }
  nextSteps: string[]
}

interface LeadData {
  nome: string
  email: string
  telefone: string
  tipoInstituicao: string
  cargo: string
  qtdFuncionarios: string
}

function getLevelText(level: string): string {
  switch (level) {
    case 'critico': return 'CRÍTICO - Riscos Elevados'
    case 'necessita_melhorias': return 'NECESSITA MELHORIAS SIGNIFICATIVAS'
    case 'precisa_tecnologia': return 'PRECISA DE TECNOLOGIA E PROCESSOS'
    case 'em_desenvolvimento': return 'EM DESENVOLVIMENTO - Oportunidade de Evolução'
    default: return ''
  }
}

function getLevelColor(level: string): [number, number, number] {
  switch (level) {
    case 'critico': return [239, 68, 68] // red
    case 'necessita_melhorias': return [249, 115, 22] // orange
    case 'precisa_tecnologia': return [245, 158, 11] // amber
    case 'em_desenvolvimento': return [59, 130, 246] // blue
    default: return [107, 114, 128] // gray
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { result, leadData } = body as { result: CheckupResult; leadData: LeadData }

    if (!result || !leadData) {
      return NextResponse.json({ error: 'Dados incompletos' }, { status: 400 })
    }

    const doc = new jsPDF()
    const pageWidth = doc.internal.pageSize.getWidth()
    const margin = 20
    let yPos = 20

    // Helper function to add text with word wrap
    const addWrappedText = (text: string, x: number, y: number, maxWidth: number, fontSize: number = 10) => {
      doc.setFontSize(fontSize)
      const lines = doc.splitTextToSize(text, maxWidth)
      doc.text(lines, x, y)
      return lines.length * (fontSize * 0.5)
    }

    // Header
    doc.setFillColor(34, 197, 94) // green-600
    doc.rect(0, 0, pageWidth, 40, 'F')
    
    doc.setTextColor(255, 255, 255)
    doc.setFontSize(24)
    doc.setFont('helvetica', 'bold')
    doc.text('LAUDO CHECKUP CME INTELIGENTE', margin, 25)
    
    doc.setFontSize(10)
    doc.setFont('helvetica', 'normal')
    doc.text('Diagnóstico de Gestão, Processo e Tecnologia', margin, 33)

    yPos = 55

    // Data de emissão
    doc.setTextColor(100, 100, 100)
    doc.setFontSize(9)
    doc.text(`Data de emissão: ${new Date().toLocaleDateString('pt-BR', { 
      year: 'numeric', 
      month: 'long', 
      day: 'numeric' 
    })}`, margin, yPos)
    yPos += 15

    // Dados do respondente
    doc.setFillColor(243, 244, 246) // gray-100
    doc.rect(margin - 5, yPos - 5, pageWidth - 2 * margin + 10, 35, 'F')
    
    doc.setTextColor(0, 0, 0)
    doc.setFontSize(11)
    doc.setFont('helvetica', 'bold')
    doc.text('DADOS DA INSTITUIÇÃO', margin, yPos + 5)
    
    doc.setFont('helvetica', 'normal')
    doc.setFontSize(10)
    yPos += 12
    doc.text(`Tipo de Instituição: ${leadData.tipoInstituicao}`, margin, yPos)
    yPos += 6
    doc.text(`Responsável: ${leadData.nome}${leadData.cargo ? ` - ${leadData.cargo}` : ''}`, margin, yPos)
    yPos += 6
    doc.text(`E-mail: ${leadData.email}`, margin, yPos)
    yPos += 6
    if (leadData.qtdFuncionarios) {
      doc.text(`Funcionários CME: ${leadData.qtdFuncionarios}`, margin, yPos)
      yPos += 6
    }
    yPos += 9

    // Resultado Geral
    doc.setFillColor(...getLevelColor(result.overallLevel))
    doc.rect(margin - 5, yPos - 5, pageWidth - 2 * margin + 10, 25, 'F')
    
    doc.setTextColor(255, 255, 255)
    doc.setFontSize(14)
    doc.setFont('helvetica', 'bold')
    doc.text(`PONTUAÇÃO GERAL: ${result.overallScore}/100 - NÍVEL ${getLevelText(result.overallLevel)}`, margin, yPos + 5)
    
    doc.setFontSize(9)
    doc.setFont('helvetica', 'normal')
    yPos += 10
    doc.text(result.overallScore < 40 
      ? 'Sua CME apresenta gaps significativos que precisam de atenção urgente.'
      : result.overallScore < 60
      ? 'Sua CME tem pontos de atenção que podem ser resolvidos com ações direcionadas.'
      : result.overallScore < 80
      ? 'Sua CME está em bom caminho, mas ainda há espaço para otimizações.'
      : 'Parabéns! Sua CME demonstra maturidade operacional.', margin, yPos)
    
    yPos += 25

    // Scores por Categoria
    doc.setTextColor(0, 0, 0)
    doc.setFontSize(12)
    doc.setFont('helvetica', 'bold')
    doc.text('ANÁLISE POR DIMENSÃO', margin, yPos)
    yPos += 10

    result.categories.forEach((cat) => {
      doc.setFillColor(...getLevelColor(cat.level))
      doc.rect(margin, yPos, 5, 20, 'F')
      
      doc.setFillColor(249, 250, 251) // gray-50
      doc.rect(margin + 6, yPos, pageWidth - 2 * margin - 6, 20, 'F')
      
      doc.setTextColor(0, 0, 0)
      doc.setFontSize(10)
      doc.setFont('helvetica', 'bold')
      doc.text(`${cat.categoryName}: ${cat.percentage}% - ${getLevelText(cat.level)}`, margin + 10, yPos + 8)
      
      doc.setFont('helvetica', 'normal')
      doc.setFontSize(8)
      doc.setTextColor(100, 100, 100)
      doc.text(cat.recommendations[0] || '', margin + 10, yPos + 15)
      
      yPos += 25
    })

    // Principais Gaps
    if (result.mainProblems.length > 0) {
      yPos += 5
      doc.setTextColor(0, 0, 0)
      doc.setFontSize(12)
      doc.setFont('helvetica', 'bold')
      doc.text('PRINCIPAIS GAPS IDENTIFICADOS', margin, yPos)
      yPos += 8

      doc.setFontSize(9)
      doc.setFont('helvetica', 'normal')
      result.mainProblems.forEach((problem) => {
        const height = addWrappedText(`• ${problem}`, margin, yPos, pageWidth - 2 * margin, 9)
        yPos += height + 3
      })
    }

    // Nova página para análise detalhada
    doc.addPage()
    yPos = 20

    doc.setTextColor(0, 0, 0)
    doc.setFontSize(12)
    doc.setFont('helvetica', 'bold')
    doc.text('ANÁLISE DETALHADA POR DIMENSÃO', margin, yPos)
    yPos += 10

    result.categories.forEach((cat) => {
      doc.setFillColor(34, 197, 94)
      doc.rect(margin, yPos, pageWidth - 2 * margin, 8, 'F')
      
      doc.setTextColor(255, 255, 255)
      doc.setFontSize(10)
      doc.setFont('helvetica', 'bold')
      doc.text(cat.categoryName.toUpperCase(), margin + 3, yPos + 6)
      yPos += 12

      doc.setTextColor(0, 0, 0)
      doc.setFont('helvetica', 'normal')
      doc.setFontSize(9)
      
      if (cat.findings.length > 0) {
        doc.text('Pontos de atenção:', margin, yPos)
        yPos += 5
        cat.findings.forEach((finding) => {
          const height = addWrappedText(`  • ${finding}`, margin, yPos, pageWidth - 2 * margin - 5, 8)
          yPos += height + 2
        })
      } else {
        doc.setTextColor(34, 197, 94)
        doc.text('✓ Nenhum gap crítico identificado nesta categoria.', margin, yPos)
        yPos += 5
      }
      
      yPos += 8
    })

    // Estimativa de Economia
    yPos += 5
    doc.setFillColor(236, 253, 245) // green-50
    doc.rect(margin - 5, yPos - 5, pageWidth - 2 * margin + 10, 25, 'F')
    
    doc.setTextColor(0, 0, 0)
    doc.setFontSize(11)
    doc.setFont('helvetica', 'bold')
    doc.text('ECONOMIA POTENCIAL ESTIMADA', margin, yPos + 3)
    
    doc.setFontSize(16)
    doc.setTextColor(22, 163, 74) // green-700
    doc.text(`${result.economyEstimate.min}% a ${result.economyEstimate.max}%`, margin, yPos + 13)
    
    doc.setFontSize(8)
    doc.setFont('helvetica', 'normal')
    doc.setTextColor(100, 100, 100)
    yPos += 25

    // Quick Wins
    doc.setTextColor(0, 0, 0)
    doc.setFontSize(11)
    doc.setFont('helvetica', 'bold')
    doc.text('QUICK WINS - AÇÕES DE IMPACTO IMEDIATO', margin, yPos)
    yPos += 8

    doc.setFontSize(9)
    doc.setFont('helvetica', 'normal')
    result.quickWins.forEach((win, idx) => {
      const height = addWrappedText(`${idx + 1}. ${win}`, margin, yPos, pageWidth - 2 * margin, 9)
      yPos += height + 4
    })

    // Nova página para próximos passos e recomendações
    doc.addPage()
    yPos = 20

    doc.setTextColor(0, 0, 0)
    doc.setFontSize(12)
    doc.setFont('helvetica', 'bold')
    doc.text('PRÓXIMOS PASSOS RECOMENDADOS', margin, yPos)
    yPos += 10

    doc.setFontSize(9)
    doc.setFont('helvetica', 'normal')
    result.nextSteps.forEach((step) => {
      const height = addWrappedText(`✓ ${step}`, margin, yPos, pageWidth - 2 * margin, 9)
      yPos += height + 5
    })

    // Solução Recomendada
    yPos += 10
    doc.setFillColor(34, 197, 94)
    doc.rect(margin - 5, yPos - 5, pageWidth - 2 * margin + 10, 45, 'F')
    
    doc.setTextColor(255, 255, 255)
    doc.setFontSize(14)
    doc.setFont('helvetica', 'bold')
    doc.text('SOLUÇÃO RECOMENDADA', margin, yPos + 5)
    
    doc.setFontSize(11)
    doc.text('CME Inteligente', margin, yPos + 15)
    
    doc.setFontSize(9)
    doc.setFont('helvetica', 'normal')
    doc.text('Sistema especializado em rastreabilidade e gestão para CME', margin, yPos + 23)
    doc.text('Supervisão ativa, validações obrigatórias e governança completa', margin, yPos + 29)
    
    yPos += 55

    // Comparativo com ERP
    doc.setTextColor(0, 0, 0)
    doc.setFontSize(11)
    doc.setFont('helvetica', 'bold')
    doc.text('DIFERENCIAL TÉCNICO', margin, yPos)
    yPos += 8

    doc.setFontSize(8)
    doc.setFont('helvetica', 'normal')
    
    const comparativo = [
      ['Aspecto', 'ERP Generalista', 'CME Inteligente'],
      ['Finalidade', 'Gestão administrativa', 'Gestão técnica especializada'],
      ['Controle', 'Passivo', 'Ativo com validações'],
      ['Rastreabilidade', 'Limitada', 'Completa (processo-paciente)'],
      ['Indicadores', 'Administrativos', 'Técnicos e operacionais'],
      ['Segurança', 'Depende da equipe', 'Blindagem operacional'],
    ]

    const colWidths = [40, 55, 75]
    comparativo.forEach((row, rowIdx) => {
      doc.setFont('helvetica', rowIdx === 0 ? 'bold' : 'normal')
      doc.setTextColor(rowIdx === 0 ? 255 : 0, rowIdx === 0 ? 255 : 0, rowIdx === 0 ? 255 : 0)
      
      if (rowIdx === 0) {
        doc.setFillColor(34, 197, 94)
        doc.rect(margin, yPos - 3, colWidths.reduce((a, b) => a + b, 0), 6, 'F')
      }
      
      let xPos = margin
      row.forEach((cell, colIdx) => {
        doc.text(cell, xPos, yPos)
        xPos += colWidths[colIdx]
      })
      yPos += rowIdx === 0 ? 8 : 6
    })

    // Assinatura do Especialista
    yPos = 250
    doc.setDrawColor(200, 200, 200)
    doc.line(margin, yPos, pageWidth - margin, yPos)
    
    yPos += 10
    doc.setTextColor(0, 0, 0)
    doc.setFontSize(10)
    doc.setFont('helvetica', 'bold')
    doc.text('LAUDO EMITIDO POR', margin, yPos)
    
    yPos += 8
    doc.setFontSize(12)
    doc.text('Klever Oliveira Lopes', margin, yPos)
    
    doc.setFontSize(9)
    doc.setFont('helvetica', 'normal')
    doc.setTextColor(34, 197, 94)
    doc.text('Especialista em Gestão e Tecnologia para CME', margin, yPos + 6)
    
    doc.setTextColor(100, 100, 100)
    doc.text('+20 anos de experiência | CME Inteligente', margin, yPos + 12)

    // Footer
    doc.setFontSize(8)
    doc.setTextColor(150, 150, 150)
    doc.text(
      'Este laudo foi gerado automaticamente pelo sistema Checkup CME Inteligente.',
      pageWidth / 2,
      285,
      { align: 'center' }
    )
    doc.text(
      'Para mais informações: cmeinteligente.blogspot.com',
      pageWidth / 2,
      290,
      { align: 'center' }
    )

    // Gerar PDF como base64
    const pdfBase64 = doc.output('datauristring')
    
    return NextResponse.json({ 
      success: true, 
      pdf: pdfBase64,
      filename: `laudo-checkup-cme-${leadData.tipoInstituicao.toLowerCase().replace(/\s+/g, '-')}.pdf`
    })
  } catch (error) {
    console.error('Erro ao gerar PDF:', error)
    return NextResponse.json({ error: 'Erro ao gerar PDF' }, { status: 500 })
  }
}
