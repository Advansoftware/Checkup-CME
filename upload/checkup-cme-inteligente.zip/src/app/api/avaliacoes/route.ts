import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { calculateResult } from '@/data/checkup-questions'

// GET - Listar todas as avaliações
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const status = searchParams.get('status')
    
    const avaliacoes = await db.avaliacao.findMany({
      where: status ? { status } : undefined,
      orderBy: { createdAt: 'desc' }
    })
    
    return NextResponse.json(avaliacoes)
  } catch (error) {
    console.error('Erro ao buscar avaliações:', error)
    return NextResponse.json(
      { error: 'Erro ao buscar avaliações' },
      { status: 500 }
    )
  }
}

// POST - Criar nova avaliação
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { leadData, answers } = body
    
    // Calcular resultado
    const resultado = calculateResult(answers)
    
    // Salvar no banco
    const avaliacao = await db.avaliacao.create({
      data: {
        nome: leadData.nome,
        email: leadData.email,
        telefone: leadData.telefone || null,
        tipoInstituicao: leadData.tipoInstituicao,
        cargo: leadData.cargo || null,
        qtdFuncionarios: leadData.qtdFuncionarios || null,
        respostas: JSON.stringify(answers),
        resultado: JSON.stringify(resultado),
        status: 'pendente'
      }
    })
    
    return NextResponse.json({ 
      success: true, 
      id: avaliacao.id,
      message: 'Avaliação registrada com sucesso! Em breve entraremos em contato.' 
    })
  } catch (error) {
    console.error('Erro ao salvar avaliação:', error)
    return NextResponse.json(
      { error: 'Erro ao salvar avaliação' },
      { status: 500 }
    )
  }
}
