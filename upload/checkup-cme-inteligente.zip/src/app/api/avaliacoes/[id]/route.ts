import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

// GET - Buscar avaliação por ID
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params
    
    const avaliacao = await db.avaliacao.findUnique({
      where: { id }
    })
    
    if (!avaliacao) {
      return NextResponse.json(
        { error: 'Avaliação não encontrada' },
        { status: 404 }
      )
    }
    
    return NextResponse.json(avaliacao)
  } catch (error) {
    console.error('Erro ao buscar avaliação:', error)
    return NextResponse.json(
      { error: 'Erro ao buscar avaliação' },
      { status: 500 }
    )
  }
}

// PATCH - Atualizar status da avaliação
export async function PATCH(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params
    const body = await request.json()
    const { status, observacoes } = body
    
    const updateData: {
      status?: string
      observacoes?: string
      dataEnvio?: Date
    } = {}
    
    if (status) {
      updateData.status = status
      if (status === 'enviado') {
        updateData.dataEnvio = new Date()
      }
    }
    
    if (observacoes !== undefined) {
      updateData.observacoes = observacoes
    }
    
    const avaliacao = await db.avaliacao.update({
      where: { id },
      data: updateData
    })
    
    return NextResponse.json(avaliacao)
  } catch (error) {
    console.error('Erro ao atualizar avaliação:', error)
    return NextResponse.json(
      { error: 'Erro ao atualizar avaliação' },
      { status: 500 }
    )
  }
}

// DELETE - Excluir avaliação
export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params
    
    await db.avaliacao.delete({
      where: { id }
    })
    
    return NextResponse.json({ success: true })
  } catch (error) {
    console.error('Erro ao excluir avaliação:', error)
    return NextResponse.json(
      { error: 'Erro ao excluir avaliação' },
      { status: 500 }
    )
  }
}
