'use client'

import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Progress } from '@/components/ui/progress'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { 
  CheckCircle2, 
  AlertTriangle, 
  AlertCircle, 
  Building2, 
  Cog, 
  Monitor, 
  FileText, 
  TrendingUp,
  DollarSign,
  Clock,
  Mail,
  Phone,
  User,
  Calendar,
  Send,
  Trash2,
  RefreshCw,
  ChevronDown,
  ChevronUp,
  Search,
  Filter,
  Sparkles,
  Target,
  Zap,
  ArrowRight,
  Lightbulb
} from 'lucide-react'
import { checkupQuestions, type Question, type CheckupResult } from '@/data/checkup-questions'

interface Avaliacao {
  id: string
  nome: string
  email: string
  telefone: string | null
  tipoInstituicao: string
  cargo: string | null
  qtdFuncionarios: string | null
  respostas: string
  resultado: string
  status: string
  dataEnvio: string | null
  observacoes: string | null
  createdAt: string
  updatedAt: string
}

export default function AdminPage() {
  const [avaliacoes, setAvaliacoes] = useState<Avaliacao[]>([])
  const [loading, setLoading] = useState(true)
  const [filtroStatus, setFiltroStatus] = useState<string>('todos')
  const [busca, setBusca] = useState('')
  const [avaliacaoExpandida, setAvaliacaoExpandida] = useState<string | null>(null)
  const [observacoes, setObservacoes] = useState<Record<string, string>>({})

  const carregarAvaliacoes = async () => {
    setLoading(true)
    try {
      const url = filtroStatus !== 'todos' 
        ? `/api/avaliacoes?status=${filtroStatus}` 
        : '/api/avaliacoes'
      const response = await fetch(url)
      const data = await response.json()
      setAvaliacoes(data)
    } catch (error) {
      console.error('Erro ao carregar avaliações:', error)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    carregarAvaliacoes()
  }, [filtroStatus])

  const marcarComoEnviado = async (id: string) => {
    try {
      const obs = observacoes[id] || ''
      await fetch(`/api/avaliacoes/${id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: 'enviado', observacoes: obs })
      })
      carregarAvaliacoes()
    } catch (error) {
      console.error('Erro ao atualizar:', error)
    }
  }

  const excluirAvaliacao = async (id: string) => {
    if (!confirm('Tem certeza que deseja excluir esta avaliação?')) return
    try {
      await fetch(`/api/avaliacoes/${id}`, { method: 'DELETE' })
      carregarAvaliacoes()
    } catch (error) {
      console.error('Erro ao excluir:', error)
    }
  }

  const getLevelColor = (level: string) => {
    switch (level) {
      case 'critico': return 'bg-red-100 text-red-800 border-red-200'
      case 'necessita_melhorias': return 'bg-orange-100 text-orange-800 border-orange-200'
      case 'precisa_tecnologia': return 'bg-amber-100 text-amber-800 border-amber-200'
      case 'em_desenvolvimento': return 'bg-blue-100 text-blue-800 border-blue-200'
      default: return 'bg-gray-100 text-gray-800'
    }
  }

  const getLevelBgColor = (level: string) => {
    switch (level) {
      case 'critico': return 'bg-red-500'
      case 'necessita_melhorias': return 'bg-orange-500'
      case 'precisa_tecnologia': return 'bg-amber-500'
      case 'em_desenvolvimento': return 'bg-blue-500'
      default: return 'bg-gray-500'
    }
  }

  const getLevelIcon = (level: string) => {
    switch (level) {
      case 'critico': return <AlertCircle className="w-4 h-4" />
      case 'necessita_melhorias': return <AlertTriangle className="w-4 h-4" />
      case 'precisa_tecnologia': return <Monitor className="w-4 h-4" />
      case 'em_desenvolvimento': return <TrendingUp className="w-4 h-4" />
      default: return null
    }
  }

  const getLevelText = (level: string) => {
    switch (level) {
      case 'critico': return 'CRÍTICO'
      case 'necessita_melhorias': return 'NECESSITA MELHORIAS'
      case 'precisa_tecnologia': return 'PRECISA TECNOLOGIA'
      case 'em_desenvolvimento': return 'EM DESENVOLVIMENTO'
      default: return ''
    }
  }

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'gestao': return <Building2 className="w-4 h-4" />
      case 'processo': return <Cog className="w-4 h-4" />
      case 'tecnologia': return <Monitor className="w-4 h-4" />
      case 'financeiro': return <DollarSign className="w-4 h-4" />
      default: return <FileText className="w-4 h-4" />
    }
  }

  const getCategoryName = (category: string) => {
    switch (category) {
      case 'gestao': return 'Gestão'
      case 'processo': return 'Processo'
      case 'tecnologia': return 'Tecnologia'
      case 'financeiro': return 'Financeiro'
      default: return category
    }
  }

  const getCategoryBgColor = (category: string) => {
    switch (category) {
      case 'gestao': return 'bg-blue-50 border-blue-200'
      case 'processo': return 'bg-green-50 border-green-200'
      case 'tecnologia': return 'bg-purple-50 border-purple-200'
      case 'financeiro': return 'bg-amber-50 border-amber-200'
      default: return 'bg-gray-50 border-gray-200'
    }
  }

  const getAnswerLabel = (question: Question, value: number) => {
    const option = question.options.find(o => o.value === value)
    return option ? option.label : 'Não respondido'
  }

  const getAnswerImpact = (question: Question, value: number) => {
    const option = question.options.find(o => o.value === value)
    return option ? option.impact : ''
  }

  const avaliacoesFiltradas = avaliacoes.filter(a => 
    a.nome.toLowerCase().includes(busca.toLowerCase()) ||
    a.email.toLowerCase().includes(busca.toLowerCase()) ||
    a.tipoInstituicao.toLowerCase().includes(busca.toLowerCase())
  )

  const pendentes = avaliacoes.filter(a => a.status === 'pendente').length
  const enviados = avaliacoes.filter(a => a.status === 'enviado').length

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 p-4 md:p-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-slate-900 mb-2">
            Painel de Avaliações CME
          </h1>
          <p className="text-slate-600">
            Gerencie as avaliações recebidas e envie resultados personalizados
          </p>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                  <FileText className="w-5 h-5 text-blue-600" />
                </div>
                <div>
                  <p className="text-2xl font-bold text-slate-900">{avaliacoes.length}</p>
                  <p className="text-sm text-slate-600">Total</p>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-amber-100 rounded-full flex items-center justify-center">
                  <Clock className="w-5 h-5 text-amber-600" />
                </div>
                <div>
                  <p className="text-2xl font-bold text-slate-900">{pendentes}</p>
                  <p className="text-sm text-slate-600">Pendentes</p>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center">
                  <CheckCircle2 className="w-5 h-5 text-green-600" />
                </div>
                <div>
                  <p className="text-2xl font-bold text-slate-900">{enviados}</p>
                  <p className="text-sm text-slate-600">Enviados</p>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="pt-6">
              <Button 
                onClick={carregarAvaliacoes} 
                variant="outline" 
                className="w-full"
                disabled={loading}
              >
                <RefreshCw className={`w-4 h-4 mr-2 ${loading ? 'animate-spin' : ''}`} />
                Atualizar
              </Button>
            </CardContent>
          </Card>
        </div>

        {/* Filtros */}
        <div className="flex flex-col md:flex-row gap-4 mb-6">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <Input
              placeholder="Buscar por nome, email ou instituição..."
              value={busca}
              onChange={(e) => setBusca(e.target.value)}
              className="pl-10"
            />
          </div>
          <div className="flex gap-2">
            <Button
              variant={filtroStatus === 'todos' ? 'default' : 'outline'}
              onClick={() => setFiltroStatus('todos')}
            >
              Todos
            </Button>
            <Button
              variant={filtroStatus === 'pendente' ? 'default' : 'outline'}
              onClick={() => setFiltroStatus('pendente')}
              className="bg-amber-500 hover:bg-amber-600"
            >
              Pendentes
            </Button>
            <Button
              variant={filtroStatus === 'enviado' ? 'default' : 'outline'}
              onClick={() => setFiltroStatus('enviado')}
              className="bg-green-500 hover:bg-green-600"
            >
              Enviados
            </Button>
          </div>
        </div>

        {/* Lista de Avaliações */}
        {loading ? (
          <div className="text-center py-12">
            <RefreshCw className="w-8 h-8 animate-spin text-slate-400 mx-auto mb-4" />
            <p className="text-slate-600">Carregando avaliações...</p>
          </div>
        ) : avaliacoesFiltradas.length === 0 ? (
          <Card>
            <CardContent className="py-12 text-center">
              <FileText className="w-12 h-12 text-slate-300 mx-auto mb-4" />
              <p className="text-slate-600">Nenhuma avaliação encontrada</p>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-4">
            {avaliacoesFiltradas.map((avaliacao) => {
              const resultado: CheckupResult = JSON.parse(avaliacao.resultado)
              const respostas: Record<string, number> = JSON.parse(avaliacao.respostas)
              const isExpanded = avaliacaoExpandida === avaliacao.id
              
              return (
                <Card key={avaliacao.id} className={`border-l-4 ${
                  avaliacao.status === 'pendente' 
                    ? 'border-l-amber-500' 
                    : 'border-l-green-500'
                }`}>
                  <CardHeader className="cursor-pointer" onClick={() => setAvaliacaoExpandida(isExpanded ? null : avaliacao.id)}>
                    <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                      <div className="flex items-center gap-4">
                        <div className="w-12 h-12 bg-slate-100 rounded-full flex items-center justify-center">
                          <User className="w-6 h-6 text-slate-600" />
                        </div>
                        <div>
                          <CardTitle className="text-lg">{avaliacao.nome}</CardTitle>
                          <CardDescription className="flex items-center gap-2">
                            <Mail className="w-3 h-3" /> {avaliacao.email}
                            {avaliacao.telefone && (
                              <>
                                <span>•</span>
                                <Phone className="w-3 h-3" /> {avaliacao.telefone}
                              </>
                            )}
                          </CardDescription>
                        </div>
                      </div>
                      
                      <div className="flex items-center gap-4">
                        <div className={`${getLevelBgColor(resultado.overallLevel)} text-white px-3 py-1 rounded-full text-sm font-medium`}>
                          {resultado.overallScore}%
                        </div>
                        
                        <Badge variant={avaliacao.status === 'pendente' ? 'default' : 'secondary'}
                          className={avaliacao.status === 'pendente' 
                            ? 'bg-amber-500' 
                            : 'bg-green-500'
                          }
                        >
                          {avaliacao.status === 'pendente' ? 'Pendente' : 'Enviado'}
                        </Badge>
                        
                        <div className="text-sm text-slate-500">
                          <Calendar className="w-3 h-3 inline mr-1" />
                          {new Date(avaliacao.createdAt).toLocaleDateString('pt-BR')}
                        </div>
                        
                        {isExpanded ? <ChevronUp className="w-5 h-5 text-slate-400" /> : <ChevronDown className="w-5 h-5 text-slate-400" />}
                      </div>
                    </div>
                  </CardHeader>
                  
                  {isExpanded && (
                    <CardContent className="border-t pt-6">
                      <Tabs defaultValue="resumo" className="w-full">
                        <TabsList className="grid w-full grid-cols-4">
                          <TabsTrigger value="resumo">Resumo</TabsTrigger>
                          <TabsTrigger value="respostas">Respostas</TabsTrigger>
                          <TabsTrigger value="analise">Análise Detalhada</TabsTrigger>
                          <TabsTrigger value="acoes">Ações</TabsTrigger>
                        </TabsList>
                        
                        {/* Tab Resumo */}
                        <TabsContent value="resumo" className="space-y-6 mt-6">
                          {/* Dados do Lead */}
                          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                            <div className="p-3 bg-slate-50 rounded-lg">
                              <p className="text-xs text-slate-500 mb-1">Instituição</p>
                              <p className="font-medium">{avaliacao.tipoInstituicao}</p>
                            </div>
                            <div className="p-3 bg-slate-50 rounded-lg">
                              <p className="text-xs text-slate-500 mb-1">Cargo</p>
                              <p className="font-medium">{avaliacao.cargo || 'Não informado'}</p>
                            </div>
                            <div className="p-3 bg-slate-50 rounded-lg">
                              <p className="text-xs text-slate-500 mb-1">Funcionários CME</p>
                              <p className="font-medium">{avaliacao.qtdFuncionarios || 'Não informado'}</p>
                            </div>
                          </div>

                          {/* Score Geral */}
                          <div className={`${getLevelBgColor(resultado.overallLevel)} text-white p-6 rounded-xl`}>
                            <div className="flex items-center justify-between">
                              <div>
                                <p className="text-white/80 text-sm">Pontuação Geral</p>
                                <p className="text-4xl font-bold">{resultado.overallScore}/100</p>
                                <p className="text-white/90 mt-1">{getLevelText(resultado.overallLevel)}</p>
                              </div>
                              <div className="w-20 h-20 bg-white/20 rounded-full flex items-center justify-center">
                                {getLevelIcon(resultado.overallLevel)}
                              </div>
                            </div>
                          </div>

                          {/* Resultado por Categoria */}
                          <div>
                            <h4 className="font-semibold mb-3">Resultado por Área</h4>
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                              {resultado.categories.map((cat) => (
                                <div key={cat.category} className={`p-4 rounded-lg border ${getCategoryBgColor(cat.category)}`}>
                                  <div className="flex items-center justify-between mb-2">
                                    <span className="flex items-center gap-2 font-medium">
                                      {getCategoryIcon(cat.category)}
                                      {cat.categoryName}
                                    </span>
                                    <Badge className={getLevelColor(cat.level)}>
                                      {cat.percentage}%
                                    </Badge>
                                  </div>
                                  <Progress value={cat.percentage} className="h-2" />
                                </div>
                              ))}
                            </div>
                          </div>

                          {/* Economia Estimada */}
                          <div className="bg-green-50 border border-green-200 rounded-xl p-6">
                            <div className="flex items-center gap-3 mb-2">
                              <DollarSign className="w-6 h-6 text-green-600" />
                              <h4 className="font-semibold text-green-800">Economia Potencial Estimada</h4>
                            </div>
                            <p className="text-3xl font-bold text-green-700">
                              {resultado.economyEstimate.min}% a {resultado.economyEstimate.max}%
                            </p>
                            <p className="text-sm text-green-600 mt-1">{resultado.economyEstimate.description}</p>
                          </div>
                        </TabsContent>
                        
                        {/* Tab Respostas Detalhadas */}
                        <TabsContent value="respostas" className="space-y-4 mt-6">
                          {['gestao', 'processo', 'tecnologia', 'financeiro'].map((categoria) => {
                            const perguntasCategoria = checkupQuestions.filter(q => q.category === categoria)
                            
                            return (
                              <div key={categoria} className={`border rounded-lg ${getCategoryBgColor(categoria)}`}>
                                <div className="flex items-center gap-2 p-4 border-b bg-white/50">
                                  {getCategoryIcon(categoria)}
                                  <h4 className="font-semibold">{getCategoryName(categoria)}</h4>
                                  <Badge variant="outline" className="ml-auto">
                                    {perguntasCategoria.length} perguntas
                                  </Badge>
                                </div>
                                <div className="divide-y">
                                  {perguntasCategoria.map((pergunta) => {
                                    const resposta = respostas[pergunta.id]
                                    const isNaoSei = resposta === 0
                                    
                                    return (
                                      <div key={pergunta.id} className="p-4">
                                        <div className="flex items-start justify-between gap-4">
                                          <div className="flex-1">
                                            <p className="font-medium text-slate-900 mb-1">
                                              {pergunta.question}
                                            </p>
                                            {pergunta.description && (
                                              <p className="text-xs text-slate-500 mb-2">
                                                {pergunta.description}
                                              </p>
                                            )}
                                          </div>
                                        </div>
                                        <div className={`mt-2 p-3 rounded-lg ${
                                          isNaoSei 
                                            ? 'bg-amber-100 border border-amber-200' 
                                            : resposta === undefined 
                                              ? 'bg-red-50 border border-red-200' 
                                              : 'bg-white border'
                                        }`}>
                                          <p className={`font-medium ${
                                            isNaoSei ? 'text-amber-800 italic' : 'text-slate-800'
                                          }`}>
                                            {resposta !== undefined 
                                              ? getAnswerLabel(pergunta, resposta)
                                              : 'Não respondido'}
                                          </p>
                                          {resposta !== undefined && (
                                            <p className={`text-sm mt-1 ${
                                              isNaoSei ? 'text-amber-700' : 'text-slate-600'
                                            }`}>
                                              {getAnswerImpact(pergunta, resposta)}
                                            </p>
                                          )}
                                        </div>
                                      </div>
                                    )
                                  })}
                                </div>
                              </div>
                            )
                          })}
                        </TabsContent>
                        
                        {/* Tab Análise Detalhada */}
                        <TabsContent value="analise" className="space-y-6 mt-6">
                          {/* Principais Problemas */}
                          <div>
                            <h4 className="font-semibold mb-3 flex items-center gap-2">
                              <AlertTriangle className="w-5 h-5 text-amber-500" />
                              Principais Gaps Identificados
                            </h4>
                            <div className="bg-amber-50 border border-amber-200 rounded-lg p-4">
                              <ul className="space-y-2">
                                {resultado.mainProblems.map((problema, idx) => (
                                  <li key={idx} className="flex items-start gap-2 text-sm">
                                    <AlertCircle className="w-4 h-4 text-amber-500 mt-0.5 flex-shrink-0" />
                                    <span className="text-slate-700">{problema}</span>
                                  </li>
                                ))}
                              </ul>
                            </div>
                          </div>

                          {/* Quick Wins */}
                          <div>
                            <h4 className="font-semibold mb-3 flex items-center gap-2">
                              <Zap className="w-5 h-5 text-yellow-500" />
                              Quick Wins - Ações de Impacto Imediato
                            </h4>
                            <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
                              <ol className="space-y-3">
                                {resultado.quickWins.map((win, idx) => (
                                  <li key={idx} className="flex items-start gap-2 text-sm">
                                    <span className="w-6 h-6 bg-yellow-200 rounded-full flex items-center justify-center text-yellow-800 font-medium text-xs flex-shrink-0">
                                      {idx + 1}
                                    </span>
                                    <span className="text-slate-700">{win}</span>
                                  </li>
                                ))}
                              </ol>
                            </div>
                          </div>

                          {/* Próximos Passos */}
                          <div>
                            <h4 className="font-semibold mb-3 flex items-center gap-2">
                              <ArrowRight className="w-5 h-5 text-blue-500" />
                              Próximos Passos Recomendados
                            </h4>
                            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                              <ul className="space-y-2">
                                {resultado.nextSteps.map((step, idx) => (
                                  <li key={idx} className="flex items-start gap-2 text-sm">
                                    <CheckCircle2 className="w-4 h-4 text-blue-500 mt-0.5 flex-shrink-0" />
                                    <span className="text-slate-700">{step}</span>
                                  </li>
                                ))}
                              </ul>
                            </div>
                          </div>

                          {/* Análise por Categoria */}
                          <div>
                            <h4 className="font-semibold mb-3">Análise Detalhada por Área</h4>
                            <div className="space-y-4">
                              {resultado.categories.map((cat) => (
                                <div key={cat.category} className={`border rounded-lg ${getCategoryBgColor(cat.category)}`}>
                                  <div className="flex items-center justify-between p-4 border-b bg-white/50">
                                    <div className="flex items-center gap-2">
                                      {getCategoryIcon(cat.category)}
                                      <span className="font-semibold">{cat.categoryName}</span>
                                    </div>
                                    <div className="flex items-center gap-2">
                                      <Badge className={getLevelColor(cat.level)}>
                                        {cat.percentage}%
                                      </Badge>
                                    </div>
                                  </div>
                                  <div className="p-4 space-y-4">
                                    {/* Findings */}
                                    <div>
                                      <p className="text-sm font-medium text-slate-600 mb-2">Pontos de Atenção:</p>
                                      {cat.findings.length > 0 ? (
                                        <ul className="space-y-1">
                                          {cat.findings.map((finding, idx) => (
                                            <li key={idx} className="text-sm text-slate-700 flex items-start gap-2">
                                              <AlertTriangle className="w-3 h-3 text-amber-500 mt-1 flex-shrink-0" />
                                              {finding}
                                            </li>
                                          ))}
                                        </ul>
                                      ) : (
                                        <p className="text-sm text-green-600">Nenhum gap crítico identificado nesta categoria.</p>
                                      )}
                                    </div>
                                    {/* Recomendações */}
                                    <div>
                                      <p className="text-sm font-medium text-slate-600 mb-2">Recomendações:</p>
                                      <ul className="space-y-1">
                                        {cat.recommendations.map((rec, idx) => (
                                          <li key={idx} className="text-sm text-slate-700 flex items-start gap-2">
                                            <Lightbulb className="w-3 h-3 text-blue-500 mt-1 flex-shrink-0" />
                                            {rec}
                                          </li>
                                        ))}
                                      </ul>
                                    </div>
                                  </div>
                                </div>
                              ))}
                            </div>
                          </div>

                          {/* Risco Financeiro */}
                          {resultado.financialRisk && (
                            <div className="bg-red-50 border border-red-200 rounded-lg p-6">
                              <h4 className="font-semibold text-red-800 mb-3 flex items-center gap-2">
                                <AlertCircle className="w-5 h-5" />
                                Risco Financeiro Identificado
                              </h4>
                              <div className="grid grid-cols-2 gap-4">
                                <div>
                                  <p className="text-sm text-red-600">Nível de Risco</p>
                                  <p className="font-bold text-red-800 text-lg">{resultado.financialRisk.riskLevel}</p>
                                </div>
                                <div>
                                  <p className="text-sm text-red-600">Perda Estimada</p>
                                  <p className="font-bold text-red-800 text-lg">{resultado.financialRisk.estimatedLoss}</p>
                                </div>
                              </div>
                              {resultado.financialRisk.description && (
                                <p className="text-sm text-red-700 mt-3">{resultado.financialRisk.description}</p>
                              )}
                            </div>
                          )}
                        </TabsContent>
                        
                        {/* Tab Ações */}
                        <TabsContent value="acoes" className="space-y-6 mt-6">
                          {/* Observações */}
                          <div>
                            <h4 className="font-semibold mb-2">Suas Observações</h4>
                            <Textarea
                              placeholder="Adicione observações sobre esta avaliação..."
                              value={observacoes[avaliacao.id] || avaliacao.observacoes || ''}
                              onChange={(e) => setObservacoes(prev => ({
                                ...prev,
                                [avaliacao.id]: e.target.value
                              }))}
                              rows={4}
                            />
                          </div>

                          {/* Ações */}
                          <div className="flex flex-wrap gap-3">
                            {avaliacao.status === 'pendente' && (
                              <Button
                                onClick={() => marcarComoEnviado(avaliacao.id)}
                                className="bg-green-600 hover:bg-green-700"
                              >
                                <Send className="w-4 h-4 mr-2" />
                                Marcar como Enviado
                              </Button>
                            )}
                            
                            <Button
                              variant="outline"
                              onClick={() => {
                                const obs = observacoes[avaliacao.id] || avaliacao.observacoes || ''
                                fetch(`/api/avaliacoes/${avaliacao.id}`, {
                                  method: 'PATCH',
                                  headers: { 'Content-Type': 'application/json' },
                                  body: JSON.stringify({ observacoes: obs })
                                })
                                alert('Observações salvas!')
                              }}
                            >
                              Salvar Observações
                            </Button>
                            
                            <Button
                              variant="destructive"
                              onClick={() => excluirAvaliacao(avaliacao.id)}
                            >
                              <Trash2 className="w-4 h-4 mr-2" />
                              Excluir
                            </Button>
                          </div>

                          {/* Contato Rápido */}
                          <div className="bg-slate-50 rounded-lg p-4">
                            <h4 className="font-medium mb-3">Contato Rápido</h4>
                            <div className="flex flex-wrap gap-2">
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => window.open(`mailto:${avaliacao.email}`, '_blank')}
                              >
                                <Mail className="w-4 h-4 mr-2" />
                                Enviar E-mail
                              </Button>
                              {avaliacao.telefone && (
                                <Button
                                  variant="outline"
                                  size="sm"
                                  onClick={() => window.open(`https://wa.me/55${avaliacao.telefone?.replace(/\D/g, '')}`, '_blank')}
                                >
                                  <Phone className="w-4 h-4 mr-2" />
                                  WhatsApp
                                </Button>
                              )}
                            </div>
                          </div>

                          {/* Data de Envio */}
                          {avaliacao.dataEnvio && (
                            <p className="text-sm text-green-600">
                              <CheckCircle2 className="w-4 h-4 inline mr-1" />
                              Resultado enviado em {new Date(avaliacao.dataEnvio).toLocaleString('pt-BR')}
                            </p>
                          )}
                        </TabsContent>
                      </Tabs>
                    </CardContent>
                  )}
                </Card>
              )
            })}
          </div>
        )}
      </div>
    </div>
  )
}
