# Checkup CME Inteligente - Guia de Deploy

Sistema de checkup gratuito para gestores de CME (Central de Material e Esterilização).

## 📋 Requisitos

- Node.js 18+ ou Bun
- PostgreSQL (recomendado para produção) ou SQLite (desenvolvimento)
- Hospedagem: Vercel, Railway, Render, DigitalOcean, etc.

---

## 🚀 Deploy Rápido

### Opção 1: Vercel (Recomendado)

1. **Fork/Clone este repositório**

2. **Crie um projeto no Vercel:**
   - Acesse [vercel.com](https://vercel.com)
   - Importe o repositório
   - Configure as variáveis de ambiente (veja abaixo)

3. **Configure o banco de dados:**
   - Recomendado: Use [Neon](https://neon.tech) ou [Supabase](https://supabase.com) para PostgreSQL gratuito
   - Ou use o Vercel Postgres

4. **Deploy automático!**

### Opção 2: Railway

1. Acesse [railway.app](https://railway.app)
2. Crie um novo projeto a partir do GitHub
3. Adicione PostgreSQL
4. Configure as variáveis de ambiente
5. Deploy!

### Opção 3: Servidor VPS/Próprio

```bash
# Clone o repositório
git clone <seu-repo>
cd checkup-cme

# Instale as dependências
npm install
# ou
bun install

# Configure o ambiente
cp .env.example .env
# Edite o .env com suas configurações

# Configure o banco
npx prisma generate
npx prisma db push

# Build
npm run build

# Inicie o servidor
npm run start
```

---

## ⚙️ Variáveis de Ambiente

Crie um arquivo `.env` na raiz do projeto:

```env
# Banco de dados - PostgreSQL (Produção)
DATABASE_URL="postgresql://usuario:senha@host:5432/nome_do_banco?schema=public"

# OU Banco de dados - SQLite (Desenvolvimento)
DATABASE_URL="file:./dev.db"

# Ambiente
NODE_ENV="production"
```

### Exemplos de DATABASE_URL:

**Neon (PostgreSQL):**
```
DATABASE_URL="postgresql://usuario:senha@ep-xxx.us-east-2.aws.neon.tech/neondb?sslmode=require"
```

**Supabase:**
```
DATABASE_URL="postgresql://postgres:senha@db.xxxxx.supabase.co:5432/postgres"
```

**Railway:**
```
DATABASE_URL="postgresql://postgres:senha@containers-us-west-xxx.railway.app:5432/railway"
```

---

## 🗄️ Configurar Banco de Dados

### PostgreSQL (Recomendado para Produção)

1. **Altere o `prisma/schema.prisma`:**

```prisma
datasource db {
  provider = "postgresql"
  url      = env("DATABASE_URL")
}
```

2. **Execute as migrations:**

```bash
npx prisma generate
npx prisma db push
```

### SQLite (Desenvolvimento)

O SQLite já está configurado por padrão. Basta executar:

```bash
npx prisma generate
npx prisma db push
```

---

## 📁 Estrutura do Projeto

```
checkup-cme/
├── src/
│   ├── app/
│   │   ├── page.tsx              # Página principal do questionário
│   │   ├── admin/page.tsx        # Painel administrativo
│   │   └── api/
│   │       └── avaliacoes/       # API de avaliações
│   ├── data/
│   │   └── checkup-questions.ts  # Perguntas do checkup
│   ├── lib/
│   │   └── db.ts                 # Conexão Prisma
│   └── components/ui/            # Componentes shadcn/ui
├── prisma/
│   └── schema.prisma             # Schema do banco de dados
├── public/
│   └── klever-foto.jpeg          # Foto do especialista
├── package.json
└── .env                          # Variáveis de ambiente
```

---

## 🔗 Rotas

| Rota | Descrição |
|------|-----------|
| `/` | Página do questionário (público) |
| `/admin` | Painel administrativo |

---

## 🔒 Proteger o Painel Admin (Opcional)

Para adicionar autenticação ao painel admin, você pode:

1. **Usar NextAuth.js** (já instalado)
2. **Adicionar autenticação básica** no middleware

Exemplo de middleware simples:

```typescript
// src/middleware.ts
import { NextResponse } from 'next/server'
import type { NextRequest } from 'next/server'

export function middleware(request: NextRequest) {
  if (request.nextUrl.pathname.startsWith('/admin')) {
    const authHeader = request.headers.get('authorization')
    
    if (!authHeader) {
      return new NextResponse(null, {
        status: 401,
        headers: {
          'WWW-Authenticate': 'Basic realm="Admin Area"'
        }
      })
    }
    
    const auth = Buffer.from(authHeader.split(' ')[1], 'base64').toString()
    const [user, pass] = auth.split(':')
    
    if (user !== 'admin' || pass !== process.env.ADMIN_PASSWORD) {
      return new NextResponse(null, { status: 401 })
    }
  }
  
  return NextResponse.next()
}
```

---

## 📊 Dados Coletados

O sistema coleta e armazena:

- **Dados do Lead:** Nome, email, telefone, instituição, cargo, qtd de funcionários
- **Respostas:** Todas as ~40 respostas do questionário
- **Resultado Calculado:** Score geral, por categoria, gaps, quick wins, recomendações

---

## 🛠️ Comandos Úteis

```bash
# Desenvolvimento
npm run dev

# Build para produção
npm run build

# Iniciar em produção
npm run start

# Visualizar banco de dados
npx prisma studio

# Criar migration
npx prisma migrate dev --name descricao

# Resetar banco (CUIDADO!)
npx prisma migrate reset
```

---

## 📞 Suporte

Desenvolvido por **Klever Oliveira Lopes**
- Especialista em CME
- +20 anos de experiência em gestão hospitalar
- [CME Inteligente](https://cmeinteligente.blogspot.com)

---

## 📝 Licença

Propriedade intelectual - Todos os direitos reservados.
